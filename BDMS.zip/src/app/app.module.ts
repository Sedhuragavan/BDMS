import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { HeaderComponent } from './Header/Header.component';
import { LoginComponent } from './Login/Login.component';
import { RegisterComponent } from './Register/Register.component';
import { ForgotComponent } from './Forgot/Forgot.component';
import { ContactusComponent } from './Contactus/Contactus.component';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule} from '@angular/forms'
import { FooterComponent } from './Footer/Footer.component';
import { BloodfactsComponent } from './bloodfacts/bloodfacts.component';
import { RequestbloodComponent } from './requestblood/requestblood.component';
import { AboutusComponent } from './Aboutus/Aboutus.component';
import { DonorComponent } from './donor/donor.component';

@NgModule({
  declarations: [						
    AppComponent,
    HomeComponent,
      HeaderComponent,
      LoginComponent,
      RegisterComponent,
      ForgotComponent,
      ContactusComponent,
      FooterComponent,
      BloodfactsComponent,
      RequestbloodComponent,
      AboutusComponent,
      DonorComponent
   ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule,ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
