import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-Contactus',
  templateUrl: './Contactus.component.html',
  styleUrls: ['./Contactus.component.css']
})
export class ContactusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
