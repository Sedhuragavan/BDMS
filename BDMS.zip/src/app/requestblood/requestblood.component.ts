import { Component, OnInit } from '@angular/core';
import { FetchDataService } from '../fetchData.service';

@Component({
  selector: 'app-requestblood',
  templateUrl: './requestblood.component.html',
  styleUrls: ['./requestblood.component.css']
})
export class RequestbloodComponent implements OnInit {
  data: any="";
  city: any="";
  bgroup: any="";
  error: boolean=false;
  hide:boolean = false;


  constructor(private fetchdata:FetchDataService) { }

  
  ngOnInit() {
    this.loadData();
  }

  loadData() {
    this.fetchdata.getData().subscribe(res => {
      this.data = res;
    });
  }

 

  search() {
    this.fetchdata.searchDonors(this.city, this.bgroup).subscribe(data => {
      if (data.length > 0) {
        this.data = data;
        this.hide=true;
        this.error = false;
      } else {
        this.data = "";
        this.error = true;
        this.hide=false;
      }
    });
  }
}
