import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-Forgot',
  templateUrl: './Forgot.component.html',
  styleUrls: ['./Forgot.component.css']
})
export class ForgotComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
