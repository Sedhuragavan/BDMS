import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bloodfacts',
  templateUrl: './bloodfacts.component.html',
  styleUrls: ['./bloodfacts.component.css']
})
export class BloodfactsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
