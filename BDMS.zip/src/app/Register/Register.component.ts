import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormControl,FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { confirmedValidator } from '../confirmpass.validator';
import { RegisterformService } from '../registerform.service';

@Component({
  selector: 'app-Register',
  templateUrl: './Register.component.html',
  styleUrls: ['./Register.component.css']
})
export class RegisterComponent implements OnInit {
rname:any="";
rage:any="";
rbgroup:any="";
rweight:any="";
remail:any="";
rphno:any="";
rcity:any="";
rpin:any="";
rpass:any="";
rcpass:any="";
rgender:any="";

 constructor(private formbuilder:FormBuilder, private route:Router, private registerform:RegisterformService) { }
  registerForm=this.formbuilder.group({
    name:[,[Validators.required,Validators.pattern,Validators.minLength(3)]],
    age:[,[Validators.required,Validators.min(18)]],
    bgroup:["",[Validators.required]],
    weight:[,[Validators.required,Validators.min(50)]],
    gender:[,[Validators.required]],
    email:[,[Validators.required, Validators.pattern]],
    phno:[,[Validators.required]],
    city:[,[Validators.required]],
    pass:[,[Validators.required]],
    cpass:[,[Validators.required]],
   

  },
  { validator: confirmedValidator('pass', 'cpass') }
  );

  ngOnInit() {
  }


  submitForm(){
    var body={
       uname:this.rname,
       age:this.rage,
       bgroup:this.rbgroup,
       weight:this.rweight,
       gender:this.rgender,
       email:this.remail,
       phno:this.rphno,
       city:this.rcity,
       pass:this.rpass,
       cpass:this.rcpass,
  
    }
    if(!this.registerForm.valid){
      alert("Please fill all the Details");
    }
    else if(this.registerForm.valid){
      this.registerform.addUserInformation(body).subscribe(data =>{
        alert("Registerd Sucessfully Press ok to Login");
        this.registerForm.reset();
        this.route.navigate(['/','login']);
      }, err=>{
        alert("Something went wrong");
      })
    }
    
  }
}
